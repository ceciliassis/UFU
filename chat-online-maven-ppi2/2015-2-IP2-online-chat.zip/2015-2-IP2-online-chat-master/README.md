# 2015-2-IP2-online-chat
Online chat in java for 2015/2 Internet Programming 2 in-class project
