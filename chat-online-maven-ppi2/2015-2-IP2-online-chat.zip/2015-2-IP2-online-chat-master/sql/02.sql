alter table users  add staus boolean
