function redireciona(param, nomeDoCampo, valorASerPassado){  
  location.href=param+"?"+nomeDoCampo+"="+valorASerPassado;  
}  